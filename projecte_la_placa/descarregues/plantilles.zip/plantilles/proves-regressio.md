# Estratègia i regressió · RA8.a–c, g

Versió inicial i versió després del canvi:
Entorn (navegador, versió, amplària, dispositiu o emulació):
Objectiu, ordre de les proves i condicions d’acceptació:
Canvi que cal verificar:

| Cas | Passos | Esperat | Abans | Després | Incidència/evidència |
| --- | --- | --- | --- | --- | --- |
| Menú ample | | | | | |
| Menú estret | | | | | |
| Escape i focus | | | | | |
| Ancoratges | | | | | |

Inclou casos que abans funcionaven per comprovar que el canvi no els ha trencat.
