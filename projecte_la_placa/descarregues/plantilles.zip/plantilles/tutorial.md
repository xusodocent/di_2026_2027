# Tutorial d’una tasca · RA6.g

Tasca:
Situació inicial:
Resultat esperat:

| Pas | Acció | Què s’ha de veure |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |

## Verificació del tutorial
Persona que l’ha provat (sense dades personals):
Resultat i millores:
