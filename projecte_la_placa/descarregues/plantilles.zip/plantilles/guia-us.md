# Guia breu d’ús · RA6.e (evidència parcial)

Versió de la interfície:
A qui s’adreça:

## Què permet fer cada pàgina

## Navegació amb ratolí i teclat

## Dificultats habituals i alternatives

## Limitacions conegudes

## Comprovació amb una persona
Data, tasca i correccions de la guia:
